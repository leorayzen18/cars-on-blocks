var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d5c4ee52-e762-47bb-ac73-4665157ed240","153d8d74-2eef-4ff4-a5c7-d22a6d7b7a34","aa70e6e7-7fc2-4452-9641-4732c815e3d4","058bebe8-91e5-4295-9ab0-b83d09d132f8","faccd1bf-d1db-4847-97de-a2570df2adc4","383c1746-2e1d-4e03-be4c-0a9edaee0789"],"propsByKey":{"d5c4ee52-e762-47bb-ac73-4665157ed240":{"name":"jamal","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/d5c4ee52-e762-47bb-ac73-4665157ed240.png","frameSize":{"x":609,"y":609},"frameCount":1,"looping":true,"frameDelay":4,"version":"57BR8hQFnyWJz5cvIqs36yG1Z.RW9XMM","loadedFromSource":true,"saved":true,"sourceSize":{"x":609,"y":609},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/d5c4ee52-e762-47bb-ac73-4665157ed240.png"},"153d8d74-2eef-4ff4-a5c7-d22a6d7b7a34":{"name":"floppa","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/153d8d74-2eef-4ff4-a5c7-d22a6d7b7a34.png","frameSize":{"x":640,"y":480},"frameCount":1,"looping":true,"frameDelay":4,"version":"3EdU2JSB1RmoLrMdovqsBY7Qf.s.0zud","loadedFromSource":true,"saved":true,"sourceSize":{"x":640,"y":480},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/153d8d74-2eef-4ff4-a5c7-d22a6d7b7a34.png"},"aa70e6e7-7fc2-4452-9641-4732c815e3d4":{"name":"therock","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/aa70e6e7-7fc2-4452-9641-4732c815e3d4.png","frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":4,"version":"68j0Hgt3.5Ghg5gpaKzocxcvtKzjPg77","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/aa70e6e7-7fc2-4452-9641-4732c815e3d4.png"},"058bebe8-91e5-4295-9ab0-b83d09d132f8":{"name":"john","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/058bebe8-91e5-4295-9ab0-b83d09d132f8.png","frameSize":{"x":1200,"y":675},"frameCount":1,"looping":true,"frameDelay":4,"version":"O7c37_.TrZz7mS_52jk_cTleTZ8xU079","loadedFromSource":true,"saved":true,"sourceSize":{"x":1200,"y":675},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/058bebe8-91e5-4295-9ab0-b83d09d132f8.png"},"faccd1bf-d1db-4847-97de-a2570df2adc4":{"name":"capivara","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/faccd1bf-d1db-4847-97de-a2570df2adc4.png","frameSize":{"x":501,"y":501},"frameCount":1,"looping":true,"frameDelay":4,"version":"kaQXPCsXETnTECfykHKx53uIcBzSB600","loadedFromSource":true,"saved":true,"sourceSize":{"x":501,"y":501},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/faccd1bf-d1db-4847-97de-a2570df2adc4.png"},"383c1746-2e1d-4e03-be4c-0a9edaee0789":{"name":"sherekbanheiro","sourceUrl":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/383c1746-2e1d-4e03-be4c-0a9edaee0789.png","frameSize":{"x":480,"y":360},"frameCount":1,"looping":true,"frameDelay":4,"version":"kwILNtLqRWRQZjM6n3uFhh1soGoGwEhU","loadedFromSource":true,"saved":true,"sourceSize":{"x":480,"y":360},"rootRelativePath":"assets/v3/animations/dxufEw8w2L61j-S9P1HuBsGeUQoAgHkMBB2h6f6fEgA/383c1746-2e1d-4e03-be4c-0a9edaee0789.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var objetivo = createSprite(365,200,52,140);
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;
 //seu objetivo e levar a capivara ao banheiro do sherek mais pra isso vc deve evitar os cacadores:therock,jamal,floppa,johnxina boa sorte!!
 
 
 
  boundary1 = createSprite(190,70,420,3);
  boundary2 = createSprite(190,310,420,3);
  sam = createSprite(20,190,13,13);
  sam.shapeColor = "green";
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
//adicione velocidade para fazer o carro se mover.
car1.velocityY=-5;
car2.velocityY=-6;
car3.velocityY=-6;
car4.velocityY=-6;

objetivo.scale=0.2;
//sam.scale=0.1;
//car1.scale=0.2;
//car4.scale=0.1;
//car3.scale=0.1;
//car2.scale=0.1;
function draw() {

background("white");  
  text("Mortes: " + life,200,100);
  rect(0,120,52,140);
  strokeWeight(0);
  fill("lightblue");
  fill("yellow");
  car1.bounceOff(boundary2);
  car2.bounceOff(boundary2);
  car3.bounceOff(boundary2);
  car4.bounceOff(boundary2);
  car1.bounceOff(boundary1);
  car2.bounceOff(boundary1);
  car3.bounceOff(boundary1);
  car4.bounceOff(boundary1);
// crie a função rebater, para fazer o carro rebater nos limites
//Adicione a condição para fazer Sam se mover para a esquerda e para a direita
//Adicione a condição para reduzir a vida de Sam quando ele encostar no carro.
 
if (keyDown("left")) {
 sam.x-=1;  
 }
 if (keyDown("right")) {
  sam.x+=1;   
 } 
 
 if (sam.isTouching(car1) || sam.isTouching(car2) || sam.isTouching(car3) || sam.isTouching(car4)) {
   life  += 1;
   sam.x = 20;
 }
if (sam.isTouching(objetivo)) {
background("green");
text("voce venceu o desafio mais dificil parabens ",144,28);
stroke(18);  
}
  
 
 
  
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
